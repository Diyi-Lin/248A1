	
	
	
	// -------------------------------------------------------
	// Assignment1
	// Written by: (Diyi Lin student id40086388)
	// For COMP 248 Section  � Fall 2018
	// --------------------------------------------------------
	
	
public class Question1 {
       
	public static void main(String[] args) {
		//Print my first name in BIG letters to finish my COMP 248 HWk//
		//Nothing about Variables or Constant//
		//Just imagine it in a rectangular coordinates,then print it row by row,column by column,and make it beautiful//
        System.out.println("    DDDDD            IIIIIIIII      YYY         YYY      IIIIIIIII");
        System.out.println("    DDD  DDD            III           YYY     YYY           III   ");
        System.out.println("    DDD    DDD          III             YYY YYY             III   ");
        System.out.println("    DDD      DDD        III               YYY               III   ");
        System.out.println("    DDD       DDD       III               YYY               III   ");
        System.out.println("    DDD      DDD        III               YYY               III   ");
        System.out.println("    DDD     DDD         III               YYY               III   ");
        System.out.println("    DDD    DDD          III               YYY               III   "); 
        System.out.println("    DDDDDDD          IIIIIIIII           YYYYY           IIIIIIIII");
        //My First name DIYI in BIG letters//
	}

}

 